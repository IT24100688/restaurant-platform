package com.restaurant.model;

import java.util.*;

public class HotelTableManager {
    private Map<String, Map<String, Queue<Table>>> hotelTables;

    public HotelTableManager() {
        hotelTables = new HashMap<>();
    }



    public void addHotel(String hotelName) {
        hotelTables.put(hotelName, new HashMap<>());

        for (String type : Arrays.asList("VIP", "Outdoor", "Family")) {
            hotelTables.get(hotelName).put(type, new LinkedList<>());
        }
    }


    public void addTable(String hotelName, String type, int count) {
        Queue<Table> tableQueue = hotelTables.get(hotelName).get(type);
        for (int i = 0; i < count; i++) {
            tableQueue.offer(new Table(type));
        }
    }

    public void removeTable(String hotelName, String type) {
        Queue<Table> tableQueue = hotelTables.get(hotelName).get(type);
        if (!tableQueue.isEmpty()) {
            tableQueue.poll();  // Remove one table
        }
    }

    public int getAvailableCount(String hotelName, String type) {
        return hotelTables.get(hotelName).get(type).size();
    }

    public Map<String, Integer> getTableCounts(String hotelName) {
        Map<String, Integer> counts = new HashMap<>();
        List<String> types = Arrays.asList("VIP", "Outdoor", "Family");

        for (String type : types) {
            counts.put(type, getAvailableCount(hotelName, type));
        }

        return counts;
    }
}
