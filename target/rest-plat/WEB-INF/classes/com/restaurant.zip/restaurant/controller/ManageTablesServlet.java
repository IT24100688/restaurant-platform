package com.restaurant.controller;

import com.restaurant.model.HotelTableManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.file.FileStore;

public class ManageTablesServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String hotel = request.getParameter("hotelName");
        String action = request.getParameter("action"); // "add" or "remove"
        String type = request.getParameter("tableType");
        int count = Integer.parseInt(request.getParameter("count"));

        HotelTableManager manager = (HotelTableManager) getServletContext().getAttribute("manager");
        if (action.equals("add")) {
            manager.addTable(hotel, type, count);
        } else if (action.equals("remove")) {
            for (int i = 0; i < count; i++) {
                manager.removeTable(hotel, type);
            }
        }

        response.sendRedirect("adminDashboard.jsp");
    }



}
